# Projet_5
Concevez la solution technique d’un système de gestion de pizzeria

Le fichier schema_OC_pizza correspond à la structure et les tables vide de la base de donnée.
Le fichier data_OC_pizza correspond aux requêtes SQL pour générer les données dans la base de donnée.
Le fichier dump_OC_pizza correpond à la structure et aux données.